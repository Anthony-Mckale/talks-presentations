from multiprocessing import Process
import os
from pathlib import Path

def fib (wanted_index: int) -> int:
    fib1=0
    fib2=1
    current_index=0
    current_fib = fib1
    while (current_index < wanted_index - 1):
        current_fib=fib1+fib2
        current_index += 1
        fib1=fib2
        fib2=current_fib
    return current_fib

def get_absolute_filename(user_inputted_filename: str) -> Path:
    """Clean up user inputted filename path, wraps os.path.abspath, returns Path object"""
    filename_location = Path(os.path.abspath(user_inputted_filename))
    return filename_location

def create_folder(file_path: str, raise_error_on_fail: bool = True):
    """
    Create folder to location file
    """
    path = Path(os.path.abspath(file_path))
    try:
        os.makedirs(path, exist_ok=True)
    except PermissionError as not_permitted_err:
        if raise_error_on_fail:
            raise Exception(f"cannot create folder '{not_permitted_err.filename}', Permission was denied")
        print(f"cannot create folder '{not_permitted_err.filename}', Permission was denied")

def write_text(file_path: str, text: str) -> str:
    """
    Save text file
    """
    location = get_absolute_filename(file_path)
    try:
        with open(location, mode="w") as text_file:
            text_file.write(text)
        text_file.close()
        return location
    except PermissionError as not_permitted_err:
        raise Exception(f"cannot write '{not_permitted_err.filename}', Permission was denied")

def info(title):
    print(title)
    print('module name:', __name__)
    print('parent process:', os.getppid())
    print('process id:', os.getpid())

if __name__ == '__main__':
    info('main line')
    create_folder('fib-sync')
    total = 10000
    for x in range(1, total + 1):
        fib_number = fib(x)
        if x % 100 == 1:
            print(f'creating fib-sync/fib-number-{x}.txt')
        write_text(f'fib-sync/fib-number-{x}.txt', str(fib_number))