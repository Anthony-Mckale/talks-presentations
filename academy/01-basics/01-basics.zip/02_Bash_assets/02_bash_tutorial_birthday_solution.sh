#!/usr/bin/env bash
# NEED TO EXTACT MONTH AND DAY NOT COMPARE YEAR
echo "What day is your birthday? (YYYY-MM-DD)"
read BIRTHDAY
TODAY=`date -I`
if [$BIRTHDAY = $TODAY]
then
	echo "Happy birthday !"
else
	echo "Sorry today (${TODAY}) is not your birthday (${BIRTHDAY})"
fi