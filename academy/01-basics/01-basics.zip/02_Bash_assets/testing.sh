#!/bin/bash

function say_hello {
    echo "hello ${1}"
}

say_hello Anthony

exit 0






# THIS IS A ECHO STATEMENT
echo "what is your name"
read JUST_A_VARIABLE
echo "Hello ${JUST_A_VARIABLE}"