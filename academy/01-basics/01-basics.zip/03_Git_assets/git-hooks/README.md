Scenario:
Example commit pre-hook

Test 1

