RAM_BOMB="YARGH"
while true
do
	RAM_BOMB="${RAM_BOMB}${RAM_BOMB}"
done