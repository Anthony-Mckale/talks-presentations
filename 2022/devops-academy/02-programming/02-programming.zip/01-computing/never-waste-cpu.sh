function infiniteLoop {
	echo "starting infiniteLoop"
	while true
	do
	    VALUE="ABC"
		for i in {1..100}
		do
		 VALUE="${VALUE}-${VALUE}"
		done
	done
}

echo "param: ${1}"
if [[ -d $1 ]]
then
	infiniteLoop
fi

./never-waste-cpu.sh child
./never-waste-cpu.sh child
./never-waste-cpu.sh child
./never-waste-cpu.sh child