with open(file_path, "r", encoding="utf-8") as text_file:
    text_str = text_file.read()
    text_file.close()
print(text_str)

with open(location, mode="w") as text_file:
    text_file.write(text)
    text_file.close()

# ps close not actually required when using with open (it automatically calls close)
# doing close out of habit

with open(file_path, "r", encoding="utf-8") as text_file:
    text_str = text_file.read()
    text_file.close()
loglines = text_str.split('\n')
print(loglines)

import json
with open(file_path, "r", encoding="utf-8") as text_file:
    jloglines = [json.loads(line) for line in f]
print(jloglines)


# As list of lists
import csv
with open(file_path, newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=' ', quotechar='|')
    for row in reader:
        print('ROW DATA! as list')
        print(', '.join(row))
       
# As list of dicts       
import csv
with open(file_path, newline='') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        print('ROW DATA! as dict')
        print(row['first_name'], row['last_name'])
        
import xmltodict
with open(file_path, "r", encoding="utf-8") as text_file:
    text_str = text_file.read()
    data = xmltodict.parse(xml_str, force_list=force_list or {})
    text_file.close()
print(data)   


with open(file_path, "r", encoding="utf-8") as text_file:
    text_str = text_file.read()
    text_file.close()
data = json.loads(json_str)
print(data)


import yaml

with open(file_path, "r") as stream:
    data = yaml.safe_load(stream)
print(data)







import urllib.request
contents = request(url, data=data, headers=headers, method=method)
json.loads(contents)     



import urllib.request
contents = request('https://amckale.com/foo?bar=1', headers={}, method='get')
text_data = contents
json_data = json.loads(contents)


import urllib.request
contents = request('https://amckale.com/foo', data=json.dumps({'some': 'thing'}), headers={}, method='post')
text_data = contents
json_data = json.loads(contents)

