def hello(param: str) -> None:
    """Echos out input"""
    print(f"hello {param} world ?")


hello("s_nake and s-pine are different")
