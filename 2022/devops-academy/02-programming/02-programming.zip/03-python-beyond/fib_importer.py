import fib

fib.fib(1000)
