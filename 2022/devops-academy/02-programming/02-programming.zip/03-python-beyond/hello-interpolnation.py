a = "Hello"
b = "World"
print(f"{a} {b}?")