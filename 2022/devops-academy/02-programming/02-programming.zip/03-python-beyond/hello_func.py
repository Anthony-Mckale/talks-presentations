def hello():
    print("hello func world ?")


hello()
