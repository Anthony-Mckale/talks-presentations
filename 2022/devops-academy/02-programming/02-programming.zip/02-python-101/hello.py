#!/usr/bin/env python

def add(a: int , b: int = 666) -> int:
    c = a + b
    print(f"{a} + {b} = {c}")
    return c

sum_of_numbers = add(a=1, b=2)
print(sum_of_numbers)

exit()

#print(list(range(1, 11)))
#exit()
c = 0
for i in range(1, 100001):
    c += i # print(i)
else:
    print('The for loop is over')

print(c)

exit()


cats: list = ['bob', 'jim']
print(cats)

dogs: list = ['jeff', 'bobbin']
print(dogs)



cats_and_dogs: dict = {
    'cats': cats,
    'dogs': dogs
}
# cats_and_dogs: list = [cats, dogs]
print(cats_and_dogs)

print("Helloworld")
