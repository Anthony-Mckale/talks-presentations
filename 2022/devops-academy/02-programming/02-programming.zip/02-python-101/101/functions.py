#!/usr/bin/env python
from sys import argv
print(f"cli arguments: {argv}")


with open('filename.txt', 'w') as filehandle:
    filehandle.write('Hello, world!\n')
exit()

import sys
print(f"cli arguments: {sys.argv}")

from sys import argv
print(f"cli arguments: {argv}")


def helloworld(some_thing):
    print(f"Hello {some_thing}")

# normal positional function
helloworld("World")

def helloworld_keyword(some_thing="default value"):
    print(f"Hello {some_thing}")

# used with keyword syntax
helloworld_keyword(some_thing="World")

# used as normal positional function
helloworld_keyword("World")

# used with default, where some_thing="default value"
helloworld_keyword()

if is_something == True:
    print('true cond')
else:
    print('false cond')
print('out of if')



