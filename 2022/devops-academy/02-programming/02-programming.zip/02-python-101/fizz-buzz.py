#!/usr/bin/env python
import sys
print("Helloworld")

count = sys.argv[1] if 1 in sys.argv else 20
fizz = sys.argv[2] if 2 in sys.argv else 3
buzz = sys.argv[3] if 3 in sys.argv else 4

for x in range(1, count + 1):
    if (x % fizz == 0 and x % buzz == 0):
        print('fizzbuzz')
    elif (x % fizz == 0):  
        print('fizz')
    elif (x % buzz == 0): 
        print('buzz') 
    else:
        print(x)