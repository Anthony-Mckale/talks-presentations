from multiprocessing import Process
import os
from pathlib import Path

import sys
print(f"cli arguments: {sys.argv}")

def fib (wanted_index: int) -> int:
    print(f"DEBUG: Calculate Fib Position = {wanted_index}")
    fib1=0
    fib2=1
    current_index=0
    current_fib = fib1

    while (current_index < wanted_index - 1):
        current_fib=fib1+fib2
        current_index += 1
        print(f"DEBUG: curr={current_fib}({current_index}), 1={fib1}, 2={fib2}")
        fib1=fib2
        fib2=current_fib
    print(f"fib number {current_index} is {current_fib}")
    return current_fib

# python fib.py 10
if __name__ == '__main__':
    fib_number = fib(int(sys.argv[1]))
    print(fib_number)
