/**
 * add two numbers together and add one
 * @param {Number} a
 * @param {Number} b
 * @return {Number}
 */
function addPlusOne(a, b) {
    return a + b
}