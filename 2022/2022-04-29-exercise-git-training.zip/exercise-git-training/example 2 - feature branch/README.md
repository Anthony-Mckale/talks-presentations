- Please switch to feature branch 'feature/adding-new-function'

- finish off the implementation of 
```js
/**
 * add two numbers together and add three
 * @param {Number} a
 * @param {Number} b
 * @return {Number}
 */
function addPlusThree(a, b) {
  return a + b + 3
}
```
- merge branch feature/adding-new-function into develop