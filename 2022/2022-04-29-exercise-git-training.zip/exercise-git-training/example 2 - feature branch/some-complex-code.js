/**
 * add two numbers together and add one
 * @param {Number} a
 * @param {Number} b
 * @return {Number}
 */
function addPlusOne(a, b) {
    return a + b + 1
}

/**
 * Hello World !
 * @param {String} hello
 * @return {String}
 */
function someNewCodeCommitSinceFeatureBranchCreated(hello) {
    return hello + 'world'
}

/**
 * add two numbers together and add two
 * @param {Number} a
 * @param {Number} b
 * @return {Number}
 */
function addPlusTwo(a, b) {
    return a + b + 2
}