Common Git Conflicit Examples 101

Example 1 - merging when master has been changed
Example 2 - merging a feature branch into develop
Example 3 - merging a feature branch that was forked from squashed branch into develop
Example 4 - merging when worksmanship has happened
