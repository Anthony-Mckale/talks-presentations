Scenario:
You have feature branch to merge in

unfortunately someone has changed the code style from tabs to spaces... on develop

Steps:

- Please switch to feature branch 'feature/new-feature'

- merge branch 'feature/new-feature' into develop
