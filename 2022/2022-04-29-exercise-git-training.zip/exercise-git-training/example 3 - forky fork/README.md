Scenario:
You have forked an existing branch that has since been squashed and merged

Merge your forked feature into develop (without breaking the org feature branch or any fixes for org feature branch)


Steps:

- Please switch to feature branch 'feature/forked-feature'

- finish off the implementation of 
```js
/**
 * add two numbers together and add three
 * @param {Number} a
 * @param {Number} b
 * @return {Number}
 */
function addPlusThree(a, b) {
  return a + b + 3
}
```
- merge branch 'feature/forked-feature' into develop
  (DO NOT BREAK BUGFIX IN develop)