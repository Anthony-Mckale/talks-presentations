/**
 * add two numbers together and add one
 * @param {Number} a
 * @param {Number} b
 * @return {Number}
 */
function addPlusOne(a, b) {
    return a + b + 1
}

/**
 * add two numbers together and add two
 * @param {Number} a
 * @param {Number} b
 * @return {Number}
 */
function addPlusTwo(a, b) {
    return a + b + 2
}

/**
 * square number
 * @param {Number} value
 * @return {Number}
 */
function orgBranchFunction(value) {
    return value * value
}